from django.contrib import admin

from app.models import Estimate

@admin.register(Estimate)
class EstimateAdmin(admin.ModelAdmin):
    list_display = ('service_type', 'years_since_cleaned', 'material_type', 'area', 'estimate_display')
    search_fields = ('service_type', 'material_type')
    list_filter = ('service_type', 'years_since_cleaned')
