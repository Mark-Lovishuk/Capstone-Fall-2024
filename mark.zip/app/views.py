from django.shortcuts import render, redirect

from app.models import Estimate

def index(request):
    if request.method == "POST":
        # Retrieve the data from the form
        service_type = request.POST.get("serviceType")
        years_since_cleaned = request.POST.get("yearsSinceCleaned")
        material_type = request.POST.get("materialType")
        estimate_display = request.POST.get("estimateDisplay")
        area = request.POST.get("area")  # Optional, based on form visibility

        # Save the data to the database
        Estimate.objects.create(
            service_type=service_type,
            years_since_cleaned=years_since_cleaned,
            material_type=material_type,
            estimate_display=estimate_display,
            area=int(area) if area else None,
        )

        # Redirect back to the form after saving
        return redirect('index')

    return render(request, "index.html")
